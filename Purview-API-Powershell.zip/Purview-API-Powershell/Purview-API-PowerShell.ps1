### Purview API via PowerShell ###
## Arindam Bandyopadhyay MSFT (arindamba@microsoft.com) ##
#
param (
    [Parameter(Mandatory=$false)]
    [string]$TenantId,
    [Parameter(Mandatory=$false)]
    [string]$SubscriptionId,
    [Parameter(Mandatory=$true)]
    [string]$PurviewAccountName,
    [Parameter(Mandatory=$false)]
    [switch]$ServicePrincipal,
    [Parameter(Mandatory=$false)]
    [string]$ApplicationID
)
############ Functions --------------------------------------------------------------------------------------------------------------------------------------------------------------------
function ReplaceRESTParametersInURI ([string] $URI) {
    $APIRefCSVParamsFirstColumn = $APIRefCSVParams | select -Unique -ExpandProperty API_PARAMETER
    foreach ($MatchParam IN $APIRefCSVParamsFirstColumn) {
        if ($URI -match $MatchParam) {
            if ($MatchParam -eq "{subscriptionId}") {
                $ParamValue = $SubscriptionId
            } elseif ($MatchParam -eq "{accountName}") {
                $ParamValue = $PurviewAccountName
            } else {
                $ParamValue = $(Write-Host "$MatchParam=" -ForegroundColor DarkCyan -NoNewLine; Read-Host)
            }
            $URI = $URI -replace $MatchParam,$ParamValue
        }
    }
    DO {
        Write-Host "Enter Any Additional Optional Parameters In name=value Format :-> "
        $OptionalParams = Read-Host
        $URI = $URI -replace $MatchParam,$ParamValue
    }
    WHILE ($OptionalParams)
    $URI = $URI + "&api-version=2021-07-01"
    RETURN $URI
}
############ Checking Login Methods --------------------------------------------------------------------------------------------------------------------------------------------------------------------

if ($PurviewAccountName) {} else {
    $PurviewAccountName = Read-Host "Please Enter Your Purview Account/Catalog Name "
}
if ($TenantId -and $SubscriptionId) {
    Set-AzContext -Tenant $TenantId -Subscription $SubscriptionId
} else {
    if ($TenantId) {
        Set-AzContext -Tenant $TenantId
    }
    else {
        $TenantId = (Get-AzContext).Tenant.Id
        $SubscriptionId = (Get-AzContext).Subscription.Id
    }
}
if ($TenantId) {
    if ($SubscriptionId) {} else {
        Write-Output "Unable To Fetch Your Azure Subscription. Please provide SubscriptionId you're connecting to....."
        $SubscriptionId = Read-Host "Please Enter Your Azure Subscription ID : "
        Select-AzSubscription -Subscription $SubscriptionId -TenantId $TenantId
    }
    Set-AzContext -Tenant $TenantId -Subscription $SubscriptionId
} else {
    Connect-AzAccount
}
$TenantId = (Get-AzContext).Tenant.Id
$SubscriptionId = (Get-AzContext).Subscription.Id

if ($TenantId) {} else {
    Write-Output "Unable To Fetch Your Azure Subscription. Please provide the TenantId and SubscriptionId you're connecting to....."
    $TenantId = Read-Host "Please Enter Your Azure Tenant ID : "
if ($SubscriptionId) {} else {
    $SubscriptionId = Read-Host "Please Enter Your Azure Subscription ID : "
}
    Connect-AzAccount -Tenant $TenantId -Subscription $SubscriptionId
}
Save-AzProfile -Path .\MyAzureProfile.JSON -Force
$TenantId = (Get-AzContext).Tenant.Id
$SubscriptionId = (Get-AzContext).Subscription.Id

############ Login Completed + Get Access Token ------------------------------------------------------------------------------------------------------------------------------------------------------------------

$AccessTokenDataMgmt = (Get-AzAccessToken -ResourceUrl "https://management.azure.com")
$AccessTokenData = (Get-AzAccessToken -ResourceUrl "https://purview.azure.net")
Write-Output $AccessTokenData

$APIRefCSV = Import-Csv -Path Purview_API_Reference.csv
$APIRefCSVParams = Import-Csv -Path Purview_API_Reference_Parameters.csv

############ Repeat Section Below To Run APIs --------------------------------------------------------------------------------------------------------------------------------------------------------------------

DO {
DO {
    $Mode = $(Write-Host "Enter :         [G] GUI - Interactive Assistance On Help, Usage & Syntax of Purview APIs         [T] Text Mode - Enter API Command(s) Manually        [Q] Quit :: " -ForegroundColor Cyan -NoNewLine; Read-Host)
} WHILE ($Mode -notin ("q","Q","g","G","t","T"))
if ($Mode.SubString(0,1) -in ("q","Q")) {  Exit 1 }
if ($Mode.SubString(0,1) -in ("g","G")) { $Mode = "G" } else { $Mode = "T" }

if ($Mode -eq "G") {
    $SelectedAPI = $APIRefCSV   | Out-GridView -Title "Execute Purview API" -OutputMode Single
    $APICategory = $SelectedAPI | Select-Object -ExpandProperty Category
    $APICommand  = $SelectedAPI | Select-Object -ExpandProperty Command
}
else {
    $ValidAPICategories = $APIRefCSV | select -Unique -ExpandProperty Category
    DO {
        $APICategory = $(Write-Host "Enter API Category : Valid Values ( $ValidAPICategories ) : " -ForegroundColor Yellow -NoNewLine; Read-Host)
    } WHILE ($APICategory -notin $ValidAPICategories)
    
    $ValidAPICommands   = $APIRefCSV | Where-Object {$_.Category -eq $APICategory} | select -ExpandProperty Command
    DO {
        $APICommand  = $(Write-Host "Enter API Command : Valid Values ( $ValidAPICommands ) : " -ForegroundColor DarkYellow -NoNewLine; Read-Host)
    } WHILE ($APICommand -notin $ValidAPICommands)

}

$APISelectedRow = $APIRefCSV | Where-Object {$_.Category -eq $APICategory -and $_.Command -eq $APICommand}
$APIDomain  = $APISelectedRow | select -ExpandProperty APIURIDomain; if ($APICategory -ne "management") { $APIDomain  = $PurviewAccountName + $APIDomain }
$APIURIPath = $APISelectedRow | select -ExpandProperty APIURIPath
$HTTPMethod = $APISelectedRow | select -ExpandProperty Method
$PurviewAPIEndpointURL = ReplaceRESTParametersInURI ($URI="https://"+$APIDomain+$APIURIPath)

Write-Host "Domain : " -NoNewLine
Write-Host $APIDomain -ForegroundColor DarkGreen 
Write-Host "Ready To Execute ::::::: API Request :-> " -NoNewLine
Write-Host $PurviewAPIEndpointURL -ForegroundColor DarkGreen 

$HTTPBody = $(Write-Host "HTTP Body (Payload) [Optional, Press Enter To Ignore Payload] :-> " -ForegroundColor White -NoNewLine; Read-Host) | ConvertTo-JSON
if ($APIDomain -contains "management.azure") {$AccessTokenData = $AccessTokenDataMgmt}
$Headers = @{}
$Headers.Add("Authorization","Bearer $($AccessTokenData.Token)")
$timer = [System.Diagnostics.Stopwatch]::StartNew()
Write-Host "Invoking API : Sending Request ... " -ForegroundColor Green
Try {
    $PurviewAPIResponse = Invoke-RestMethod -Method $HTTPMethod -Uri $PurviewAPIEndpointURL -Headers $Headers -Body $HTTPBody
} Catch {
    Write-Host $_ :-> $_.Exception
}
$timer.Stop()
Write-Host "API Response Received :-> " -ForegroundColor Green
Write-Output $PurviewAPIResponse | ConvertTo-JSON
Write-Host "API Latency / Time Elapsed :-> " -ForegroundColor Green
Write-Output $timer.Elapsed
}
WHILE (1)

############## END --------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Rudimentary way of fetching Access Token
#$PostBody = @{grant_type='client_credentials'; client_id='servicePrincipalId'; client_secret='servicePrincipalKey'; resource="https://purview.azure.net"} | ConvertTo-Json
#$AccessTokenData = Invoke-WebRequest -UseBasicParsing https://login.windows.net/$TenantId/oauth2/token -ContentType "application/json" -Method POST -Body $PostBody
#
# Future Support for Service Principal
# If -ServicePricipal = TRUE, which is when user wants to login via Service Principal, user must Enter "ApplicationID" for the username and "ServicePrincipalSecret" as the password.
# Otherwise script will prompt for service principal credentials and stores them for the session. Enter your application ID for the username and service principal secret as the password when prompted.
# The ServicePrincipal switch parameter indicates that the account authenticates as a service principal.